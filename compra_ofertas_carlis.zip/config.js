window.config = {
   "model_": "AppConfig",
   "id": 1,
   "appName": "Compra Ofertas Carlis",
   "version": "1.0.0",
   "homepage": "https://t.me/Compra_Ofertas_Carlis",
   "enableNavBttns": false,
   "enableHomeBttn": true,
   "enableReloadBttn": true,
   "enableLogoutBttn": false,
   "sessionDataTimeoutTime": 0,
   "termsOfService": "Comercializadora Carlis & Servicios DEV WEB Carlis\u000aEn uso de sus condiciones y propiedades intelectuales del producto, se reserva el derecho del contenido de información del sitio.El contenido Lo que conlleva a que su contenido y lo expresado en el, se pública conforme lo establecido a las leyes internacionales y las normas establecidas para el uso de un internet libre sin restricciones. El contenido, así como la publicidad de uso es propiedad comercial y mercantil de Comercializadora Carlis. El usuario y/o visitante del sitio web, se ajusta a las normas establecidas en ley para uso y disfrute sin restricciones de su contenido, gozando de los derechos y facultades que fijan las leyes en respeto a sus derechos y privacidad de su información.\u000a\u000aComercializadora Carlis y su sitio en conveniencia a lo establecido legalmente, no hará, ni obtendrá, ni solicitará ninguna información personal para su uso, ajustándose a lo convenido en las pautas comerciales para la adquisición de bienes y servicios. Comercializadora Carlis es una empresa activa, declarada y legalmente constituida que opera comercialmente en la ciudad de Santa Bárbara de Barinas ZP 5210 del estado Barinas - Venezuela y registrada mercantilmente para su actividad fiscal y comercial desde el año 2008.\u000a\u000aEl uso de nuestros sitios, aplicativos web, marketing e imagen comercial y digital, están destinados para la actividad empresarial para uso y disfrute de sus clientes, relacionados y socios comerciales.",
   "rotation": "90",
   "kioskEnabled": false
};